import { BrowserRouter, Routes, Route } from "react-router-dom";
import ToastProvider from "./components/ToastProvider";

import Landing from "./pages/Landing";
import Login from "./pages/Login";

import Dashboard from "./pages/Dashboard";
import Warehouses from "./pages/Warehouses";
import Inventory from "./pages/Inventory";
import Orders from "./pages/Orders";
import Routing from "./pages/Routing";
import Vehicles from "./pages/Vehicles";
import OrderTimeline from "./pages/OrderTimeline";
import RealTimeTracking from "./pages/RealTimeTracking";
import ProductCatalog from "./pages/ProductCatalog";
import CustomerDashboard from "./pages/CustomerDashboard";
import CustomerOrderCreation from "./pages/CustomerOrderCreation";
import ProtectedRoute from "./components/ProtectedRoute";
import OrderDetails from "./pages/OrderDetails";
import Register from "./pages/Register";
import CustomerProfileSetup from "./pages/CustomerProfileSetup";



function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/*  Public Routes */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />

        {/*  Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/warehouses"
          element={
            <ProtectedRoute>
              <Warehouses />
            </ProtectedRoute>
          }
        />

        <Route
          path="/inventory"
          element={
            <ProtectedRoute>
              <Inventory />
            </ProtectedRoute>
          }
        />

        <Route
          path="/orders"
          element={
            <ProtectedRoute>
              <Orders />
            </ProtectedRoute>
          }
        />

        <Route
          path="/routing"
          element={
            <ProtectedRoute>
              <Routing />
            </ProtectedRoute>
          }
        />

        <Route
          path="/products"
          element={
            <ProtectedRoute>
              <ProductCatalog />
            </ProtectedRoute>
          }
        />

        <Route
          path="/vehicles"
          element={
            <ProtectedRoute>
              <Vehicles />
            </ProtectedRoute>
          }
        />

        <Route
          path="/order-timeline/:orderId"
          element={
            <ProtectedRoute>
              <OrderTimeline />
            </ProtectedRoute>
          }
        />

        <Route
          path="/order/:orderId/tracking"
          element={
            <ProtectedRoute>
              <RealTimeTracking />
            </ProtectedRoute>
          }
        />

        <Route 
          path="/orders/:orderId" element={<ProtectedRoute><OrderDetails /></ProtectedRoute>} />

        <Route path="/register" element={<Register />} />

        <Route
          path="/customer/profile-setup"
          element={<CustomerProfileSetup />}
        />

        <Route
          path="/customer/create-order"
          element={
            <ProtectedRoute>
              <CustomerOrderCreation />
            </ProtectedRoute>
          }
        />

        <Route
          path="/customer/dashboard"
          element={
            <ProtectedRoute>
              <CustomerDashboard />
            </ProtectedRoute>
          }
        />

      </Routes>
      <ToastProvider />
    </BrowserRouter>
  );
}

export default App;
