export const mockUser = {
  username: "demo_user",
  role: "ADMIN", // ADMIN | MANAGER | CUSTOMER
};

export const isMockAuthEnabled = true;
